package com.chafiktech.credit;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import org.json.*;
import java.util.*;

public class Database extends SQLiteOpenHelper {
    public Database(Context c) { super(c, "chafik_credit.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase d) {
        d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,notes TEXT)");
        d.execSQL("CREATE TABLE debts(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER NOT NULL,amount REAL NOT NULL,description TEXT,date TEXT)");
        d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,debt_id INTEGER NOT NULL,amount REAL NOT NULL,note TEXT,date TEXT)");
    }
    @Override public void onUpgrade(SQLiteDatabase d,int o,int n) {}
    public long addCustomer(String n,String p,String notes) {
        ContentValues v=new ContentValues(); v.put("name",n);v.put("phone",p);v.put("notes",notes);
        return getWritableDatabase().insert("customers",null,v);
    }
    public long addDebt(long cid,double a,String desc,String date) {
        ContentValues v=new ContentValues();v.put("customer_id",cid);v.put("amount",a);v.put("description",desc);v.put("date",date);
        return getWritableDatabase().insert("debts",null,v);
    }
    public long addPayment(long did,double a,String note,String date) {
        ContentValues v=new ContentValues();v.put("debt_id",did);v.put("amount",a);v.put("note",note);v.put("date",date);
        return getWritableDatabase().insert("payments",null,v);
    }
    public Cursor customers(String search) {
        return getReadableDatabase().rawQuery("SELECT c.id,c.name,c.phone,COALESCE((SELECT SUM(d.amount) FROM debts d WHERE d.customer_id=c.id),0),COALESCE((SELECT SUM(p.amount) FROM payments p JOIN debts d ON p.debt_id=d.id WHERE d.customer_id=c.id),0) FROM customers c WHERE c.name LIKE ? OR c.phone LIKE ? ORDER BY c.name",new String[]{"%"+search+"%","%"+search+"%"});
    }
    public Cursor debts(long cid) {
        return getReadableDatabase().rawQuery("SELECT d.id,d.amount,d.description,d.date,COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.debt_id=d.id),0) FROM debts d WHERE d.customer_id=? ORDER BY d.id DESC",new String[]{String.valueOf(cid)});
    }
    public Cursor payments(long did) {
        return getReadableDatabase().rawQuery("SELECT amount,note,date FROM payments WHERE debt_id=? ORDER BY id DESC",new String[]{String.valueOf(did)});
    }
    public Cursor customer(long id) { return getReadableDatabase().rawQuery("SELECT name,phone,notes FROM customers WHERE id=?",new String[]{String.valueOf(id)}); }
    public double[] totals() {
        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE((SELECT SUM(amount) FROM debts),0),COALESCE((SELECT SUM(amount) FROM payments),0)",null);
        c.moveToFirst(); double[] a={c.getDouble(0),c.getDouble(1),c.getDouble(0)-c.getDouble(1)};c.close();return a;
    }
    public JSONObject exportJson() throws JSONException {
        JSONObject root=new JSONObject(); JSONArray cs=new JSONArray();
        Cursor c=getReadableDatabase().rawQuery("SELECT id,name,phone,notes FROM customers",null);
        while(c.moveToNext()) {
            long cid=c.getLong(0); JSONObject co=new JSONObject();
            co.put("name",c.getString(1));co.put("phone",c.getString(2));co.put("notes",c.getString(3));
            JSONArray ds=new JSONArray(); Cursor d=debts(cid);
            while(d.moveToNext()) {
                long did=d.getLong(0);JSONObject de=new JSONObject();
                de.put("amount",d.getDouble(1));de.put("description",d.getString(2));de.put("date",d.getString(3));
                JSONArray ps=new JSONArray();Cursor p=payments(did);
                while(p.moveToNext()){JSONObject po=new JSONObject();po.put("amount",p.getDouble(0));po.put("note",p.getString(1));po.put("date",p.getString(2));ps.put(po);}p.close();
                de.put("payments",ps);ds.put(de);
            }
            d.close();co.put("debts",ds);cs.put(co);
        }
        c.close();root.put("customers",cs);root.put("format","CHAFIK-CREDIT-1");return root;
    }
    public void importJson(JSONObject root) throws JSONException {
        if(!"CHAFIK-CREDIT-1".equals(root.optString("format"))) throw new JSONException("ملف النسخة الاحتياطية غير معروف");
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {
            JSONArray cs=root.getJSONArray("customers");
            for(int i=0;i<cs.length();i++){
                JSONObject co=cs.getJSONObject(i);long cid=addCustomer(co.optString("name"),co.optString("phone"),co.optString("notes"));
                JSONArray ds=co.optJSONArray("debts");if(ds==null)continue;
                for(int j=0;j<ds.length();j++){JSONObject de=ds.getJSONObject(j);long did=addDebt(cid,de.optDouble("amount"),de.optString("description"),de.optString("date"));
                    JSONArray ps=de.optJSONArray("payments");if(ps!=null)for(int k=0;k<ps.length();k++){JSONObject po=ps.getJSONObject(k);addPayment(did,po.optDouble("amount"),po.optString("note"),po.optString("date"));}
                }
            }
            db.setTransactionSuccessful();
        } finally {db.endTransaction();}
    }
}
