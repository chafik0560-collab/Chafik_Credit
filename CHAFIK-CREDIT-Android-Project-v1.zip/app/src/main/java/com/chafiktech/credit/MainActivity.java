package com.chafiktech.credit;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    Database db; LinearLayout page; EditText search; long selectedCustomer=-1, selectedDebt=-1;
    static final int BACKUP=10, RESTORE=11;
    final String green="#16834A", dark="#123B2A", pale="#EAF5EE";
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(18,59,42));getWindow().setNavigationBarColor(Color.BLACK);db=new Database(this);home();}
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    GradientDrawable bg(String color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(Color.parseColor(color));d.setCornerRadius(dp(radius));return d;}
    TextView text(String s,int size,String color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.parseColor(color));t.setGravity(Gravity.RIGHT);t.setTypeface(null,bold?1:0);t.setPadding(dp(8),dp(7),dp(8),dp(7));return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);l.setPadding(dp(16),dp(12),dp(16),dp(18));return l;}
    void base(String title){page=column();page.setBackgroundColor(Color.WHITE);ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.addView(page);setContentView(sc);TextView h=text("CHAFIK CREDIT  |  "+title,21,dark,true);h.setBackground(bg(pale,16));page.addView(h,new LinearLayout.LayoutParams(-1,-2));}
    void button(LinearLayout box,String label,Runnable run){TextView b=text(label,16,"#FFFFFF",true);b.setGravity(Gravity.CENTER);b.setBackground(bg(green,14));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(49));p.setMargins(0,dp(6),0,dp(6));box.addView(b,p);b.setOnClickListener(v->run.run());}
    EditText field(String hint,boolean number){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setTextSize(16);e.setPadding(dp(12),dp(8),dp(12),dp(8));e.setBackground(bg("#F2F5F3",10));if(number)e.setInputType(8194);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(48));p.setMargins(0,dp(5),0,dp(5));returnFieldHack(e);return e;}
    void returnFieldHack(EditText e){}
    String money(double n){return String.format(Locale.US,"%,.2f دج",n);}
    String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    void home(){
        selectedCustomer=-1;base("لوحة التحكم");double[] t=db.totals();
        page.addView(text("مرحباً بك في نظام إدارة الديون",17,dark,true));
        stat("إجمالي الديون",money(t[0]));stat("المبالغ المستخلصة",money(t[1]));stat("الديون المتبقية",money(t[2]));
        button(page,"＋ إضافة زبون جديد",this::addCustomer);
        button(page,"👥 قائمة الزبائن والبحث",this::customers);
        button(page,"📄 تصدير تقرير PDF",this::report);
        button(page,"💾 نسخة احتياطية للبيانات",()->new AlertDialog.Builder(this).setMessage("إنشاء نسخة احتياطية بصيغة JSON؟").setPositiveButton("متابعة",(a,b)->createBackup()).setNegativeButton("إلغاء",null).show());
        button(page,"↩ استرجاع نسخة احتياطية",()->new AlertDialog.Builder(this).setMessage("سيتم إضافة بيانات النسخة إلى البيانات الحالية دون حذفها. هل تريد المتابعة؟").setPositiveButton("اختيار ملف",(a,b)->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,RESTORE);}).setNegativeButton("إلغاء",null).show());
        page.addView(text("البيانات محفوظة محلياً على هذا الهاتف وتعمل دون إنترنت.",13,"#60766A",false));
    }
    void stat(String label,String value){LinearLayout c=new LinearLayout(this);c.setOrientation(1);c.setPadding(dp(14),dp(9),dp(14),dp(9));c.setBackground(bg(pale,14));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(5),0,dp(5));page.addView(c,p);c.addView(text(label,14,dark,false));c.addView(text(value,20,green,true));}
    void addCustomer(){
        base("إضافة زبون");EditText n=field("اسم الزبون",false),p=field("رقم الهاتف",true),notes=field("ملاحظات (اختياري)",false);page.addView(n);page.addView(p);page.addView(notes);
        button(page,"حفظ الزبون",()->{if(n.getText().toString().trim().isEmpty()){toast("يرجى إدخال اسم الزبون");return;}long id=db.addCustomer(n.getText().toString().trim(),p.getText().toString(),notes.getText().toString());if(id>0){toast("تم حفظ الزبون");customerDetail(id);}else toast("تعذر حفظ الزبون");});
        button(page,"رجوع",this::home);
    }
    void customers(){
        base("الزبائن");search=field("ابحث بالاسم أو الهاتف",false);page.addView(search);LinearLayout list=new LinearLayout(this);list.setOrientation(1);page.addView(list);Runnable refresh=()->{list.removeAllViews();Cursor c=db.customers(search.getText().toString());while(c.moveToNext()){long id=c.getLong(0);String name=c.getString(1),phone=c.getString(2);double due=c.getDouble(3)-c.getDouble(4);TextView item=text(name+"  |  "+(phone==null?"":phone)+"\nالمتبقي: "+money(due),16,dark,true);item.setBackground(bg("#F2F7F3",12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));list.addView(item,lp);item.setOnClickListener(v->customerDetail(id));}c.close();if(list.getChildCount()==0)list.addView(text("لا يوجد زبائن مطابقون للبحث.",14,"#60766A",false));};search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){refresh.run();}public void afterTextChanged(android.text.Editable e){}});refresh.run();button(page,"＋ إضافة زبون",this::addCustomer);button(page,"الرئيسية",this::home);
    }
    void customerDetail(long id){
        selectedCustomer=id;Cursor info=db.customer(id);String name="زبون",phone="",notes="";if(info.moveToFirst()){name=info.getString(0);phone=info.getString(1);notes=info.getString(2);}info.close();
        base("ملف الزبون");page.addView(text(name,22,dark,true));page.addView(text("الهاتف: "+(phone==null?"":phone),15,dark,false));if(notes!=null&&!notes.isEmpty())page.addView(text("ملاحظات: "+notes,14,"#60766A",false));
        button(page,"＋ تسجيل دين جديد",()->addDebt(id));Cursor c=db.debts(id);double total=0,paid=0;
        while(c.moveToNext()){long did=c.getLong(0);double amount=c.getDouble(1),payments=c.getDouble(4);total+=amount;paid+=payments;String desc=c.getString(2),date=c.getString(3);LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(10),dp(6),dp(10),dp(6));card.setBackground(bg("#F2F7F3",12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));page.addView(card,lp);card.addView(text((desc==null||desc.isEmpty()?"دين":desc)+"  •  "+date,15,dark,true));card.addView(text("الأصل: "+money(amount)+" | المسدد: "+money(payments)+" | الباقي: "+money(amount-payments),13,green,false));TextView pay=text("＋ تسجيل تسديد",14,green,true);card.addView(pay);pay.setOnClickListener(v->addPayment(did,amount-payments,id));}c.close();
        stat("إجمالي ديون الزبون",money(total));stat("المسدد",money(paid));stat("المتبقي",money(total-paid));button(page,"إضافة تسديد من قائمة الديون",()->{Cursor d=db.debts(id);if(d.moveToFirst()){long did=d.getLong(0);double remain=d.getDouble(1)-d.getDouble(4);d.close();addPayment(did,remain,id);}else{d.close();toast("لا توجد ديون");}});button(page,"رجوع إلى الزبائن",this::customers);
    }
    void addDebt(long cid){base("تسجيل دين");EditText a=field("المبلغ بالدينار",true),d=field("وصف الدين",false);page.addView(a);page.addView(d);button(page,"حفظ الدين",()->{double amount=parse(a.getText().toString());if(amount<=0){toast("أدخل مبلغاً صحيحاً");return;}db.addDebt(cid,amount,d.getText().toString(),today());toast("تم تسجيل الدين");customerDetail(cid);});button(page,"إلغاء",()->customerDetail(cid));}
    void addPayment(long did,double remain,long cid){base("تسجيل تسديد");page.addView(text("المبلغ المتبقي: "+money(remain),17,dark,true));EditText a=field("مبلغ التسديد",true),note=field("ملاحظة (اختياري)",false);page.addView(a);page.addView(note);button(page,"حفظ التسديد",()->{double amount=parse(a.getText().toString());if(amount<=0||amount>remain+0.0001){toast("المبلغ غير صحيح أو أكبر من المتبقي");return;}db.addPayment(did,amount,note.getText().toString(),today());toast("تم تسجيل التسديد");customerDetail(cid);});button(page,"إلغاء",()->customerDetail(cid));}
    double parse(String s){try{return Double.parseDouble(s.trim().replace(",","."));}catch(Exception e){return 0;}}
    void createBackup(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"CHAFIK-CREDIT-backup-"+today()+".json");startActivityForResult(i,BACKUP);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;try{if(req==20){try(OutputStream o=getContentResolver().openOutputStream(data.getData())){reportPdf.writeTo(o);reportPdf.close();reportPdf=null;}toast("تم حفظ تقرير PDF");}else if(req==BACKUP){try(OutputStream o=getContentResolver().openOutputStream(data.getData())){o.write(db.exportJson().toString(2).getBytes("UTF-8"));}toast("تم إنشاء النسخة الاحتياطية");}else if(req==RESTORE){try(InputStream in=getContentResolver().openInputStream(data.getData())){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))>0)b.write(buf,0,n);db.importJson(new JSONObject(b.toString("UTF-8")));}toast("تم استرجاع البيانات");home();}}catch(Exception e){toast("تعذر إكمال العملية: "+e.getMessage());}}
    void report(){
        try{PdfDocument pdf=new PdfDocument();PdfDocument.PageInfo pi=new PdfDocument.PageInfo.Builder(595,842,1).create();PdfDocument.Page p=pdf.startPage(pi);Canvas c=p.getCanvas();Paint paint=new Paint(3);paint.setColor(Color.rgb(18,59,42));paint.setTextSize(22);c.drawText("CHAFIK CREDIT - تقرير الديون",40,55,paint);paint.setTextSize(13);double[] t=db.totals();c.drawText("Total debts: "+money(t[0]),40,95,paint);c.drawText("Collected: "+money(t[1]),40,120,paint);c.drawText("Remaining: "+money(t[2]),40,145,paint);int y=190;Cursor cu=db.customers("");while(cu.moveToNext()&&y<790){String line=cu.getString(1)+" | "+money(cu.getDouble(3)-cu.getDouble(4));c.drawText(line,40,y,paint);y+=24;}cu.close();pdf.finishPage(p);Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/pdf");i.putExtra(Intent.EXTRA_TITLE,"CHAFIK-CREDIT-report-"+today()+".pdf");reportPdf=pdf;startActivityForResult(i,20);}catch(Exception e){toast("تعذر إعداد التقرير");}
    }
    PdfDocument reportPdf;
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
